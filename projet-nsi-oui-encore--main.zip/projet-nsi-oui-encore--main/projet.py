import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
import networkx as nx
import matplotlib.pyplot as plt
from PIL import Image, ImageTk

# Connexion à la base de données
connexion = sqlite3.connect('voiture.db')

# Fenêtre principale
root = tk.Tk()
root.attributes("-fullscreen", True)
root.title("Gestion de véhicules")

# ====================
# = Fonctions utiles =
# ====================

def ajouter_vehicule():
    def ajouter():
        try:
            valeurs = [entrees[i].get() for i in range(len(champs))]
            valeurs[2] = int(valeurs[2])  # annee
            valeurs[3] = int(valeurs[3])  # kilometrage
            valeurs[4] = int(valeurs[4])  # puissance
            valeurs[5] = int(valeurs[5])  # poids
            valeurs[8] = int(valeurs[8])  # prix
            valeurs[10] = int(valeurs[10])  # critair
            valeurs[11] = int(valeurs[11])  # coffre
            valeurs[12] = float(valeurs[12])  # hauteur
            valeurs[13] = float(valeurs[13])  # longueur
            valeurs[14] = float(valeurs[14])  # largeur

            curseur = connexion.cursor()
            curseur.execute("""
                INSERT INTO voiture(marque, modele, annee, kilometrage, puissance, poids, couleur, etat, prix, type, critair, coffre, hauteur, longueur, largeur)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, tuple(valeurs))
            connexion.commit()
            fenetre_ajout.destroy()
            afficher_vehicules()
        except Exception as e:
            messagebox.showerror("Erreur", str(e))

    fenetre_ajout = tk.Toplevel(root)
    fenetre_ajout.title("Ajouter un véhicule")

    champs = ["Marque", "Modele", "Annee", "Kilometrage", "Puissance", "Poids",
              "Couleur", "Etat", "Prix", "Type", "Crit'air", "Coffre", "Hauteur", "Longueur", "Largeur"]
    entrees = []

    for i, champ in enumerate(champs):
        tk.Label(fenetre_ajout, text=champ).grid(row=i, column=0)
        entree = tk.Entry(fenetre_ajout)
        entree.grid(row=i, column=1)
        entrees.append(entree)

    tk.Button(fenetre_ajout, text="Ajouter", command=ajouter).grid(row=len(champs), columnspan=2)


def supprimer_vehicule():
    selected = tree.selection()
    if not selected:
        messagebox.showwarning("Attention", "Sélectionnez un véhicule à supprimer.")
        return
    item = tree.item(selected)
    vehicule_id = item['values'][0]
    curseur = connexion.cursor()
    curseur.execute("DELETE FROM voiture WHERE id = ?", (vehicule_id,))
    connexion.commit()
    afficher_vehicules()

def creer_graphe():
    graphe = nx.Graph()
    curseur = connexion.cursor()
    curseur.execute("SELECT * FROM voiture")
    for row in curseur:
        car_id = f"{row[0]}-{row[1]} {row[2]}"
        owner_id = row[6]  # Utilise la couleur comme "propriétaire" fictif pour démo
        graphe.add_node(car_id, label="car")
        graphe.add_node(owner_id, label="owner")
        graphe.add_edge(car_id, owner_id)
    curseur.close()

    # Utiliser une disposition avec plus d'itérations pour mieux espacer les nœuds
    pos = nx.spring_layout(graphe, k=3.0, iterations=100)

    # Créer la figure du graphe
    plt.figure(figsize=(20, 15))
    nx.draw(graphe, pos, with_labels=True, node_size=1500, node_color='lightblue', font_size=10, font_weight='bold', width=2)
    
    # Sauvegarder et afficher l'image
    plt.savefig("graphe.png", bbox_inches='tight', dpi=300)
    plt.close()

    afficher_image()
    graphe = nx.Graph()
    curseur = connexion.cursor()
    curseur.execute("SELECT * FROM voiture")
    for row in curseur:
        car_id = f"{row[0]}-{row[1]} {row[2]}"
        owner_id = row[6]  # On prend la couleur comme "propriétaire" fictif pour démo
        graphe.add_node(car_id, label="car")
        graphe.add_node(owner_id, label="owner")
        graphe.add_edge(car_id, owner_id)
    curseur.close()

    pos = nx.spring_layout(graphe, k=2.0)
    plt.figure(figsize=(20, 15))
    nx.draw(graphe, pos, with_labels=True, node_size=2000, node_color='lightblue', font_size=10, font_weight='bold')
    plt.savefig("graphe.png", bbox_inches='tight', dpi=300)
    plt.close()
    afficher_image()

def afficher_vehicules():
    for row in tree.get_children():
        tree.delete(row)
    curseur = connexion.cursor()
    curseur.execute("SELECT * FROM voiture")
    for row in curseur.fetchall():
        # Ne pas afficher l'ID (index 0)
        tree.insert("", "end", values=row[1:])  # On saute la première colonne (ID)

def rechercher_vehicule():
    def get_unique_values(colonne):
        try:
            curseur = connexion.cursor()
            curseur.execute(f"SELECT DISTINCT [{colonne}] FROM voiture")
            return [row[0] for row in curseur.fetchall() if row[0] is not None]
        except Exception as e:
            messagebox.showerror("Erreur", f"Impossible de charger les valeurs : {e}")
            return []

    def on_champ_change(event=None):
        champ = liste_champs.get()
        champs_combo = ["Marque", "Modele", "Couleur", "Etat", "Type", "Crit'air"]


        for widget in frame_valeur.winfo_children():
            widget.destroy()

        if champ in champs_combo:
            colonne_sql = options[champ][0]
            valeurs_possibles = get_unique_values(colonne_sql)
            combobox_valeurs = ttk.Combobox(frame_valeur, values=valeurs_possibles)
            combobox_valeurs.grid(row=0, column=0)
            combobox_valeurs.current(0 if valeurs_possibles else -1)
            frame_valeur.widget = combobox_valeurs
        else:
            entry_valeur = tk.Entry(frame_valeur)
            entry_valeur.grid(row=0, column=0)
            frame_valeur.widget = entry_valeur

    def lancer_recherche():
        try:
            champ = liste_champs.get()
            widget_valeur = getattr(frame_valeur, 'widget', None)

            if not widget_valeur:
                messagebox.showerror("Erreur", "Aucun champ de valeur défini.")
                return

            valeur = widget_valeur.get()

            if champ not in options:
                messagebox.showerror("Erreur", "Champ invalide.")
                return

            colonne, operateur, conversion = options[champ]
            valeur_convertie = conversion(valeur)

            curseur = connexion.cursor()
            query = f"SELECT * FROM voiture WHERE {colonne} {operateur} ?"
            curseur.execute(query, (valeur_convertie,))
            resultats = curseur.fetchall()

            for row in tree.get_children():
                tree.delete(row)

            for row in resultats:
                tree.insert("", "end", values=row[1:])

            fenetre_recherche.destroy()

        except Exception as e:
            messagebox.showerror("Erreur", str(e))

    # Création de la fenêtre de recherche
    fenetre_recherche = tk.Toplevel(root)
    fenetre_recherche.title("Rechercher un véhicule")

    tk.Label(fenetre_recherche, text="Critère :").grid(row=0, column=0)
    liste_champs = ttk.Combobox(fenetre_recherche, values=list(options.keys()))
    liste_champs.grid(row=0, column=1)
    liste_champs.current(0)
    liste_champs.bind("<<ComboboxSelected>>", on_champ_change)

    tk.Label(fenetre_recherche, text="Valeur :").grid(row=1, column=0)
    frame_valeur = tk.Frame(fenetre_recherche)
    frame_valeur.grid(row=1, column=1)

    # Conteneur dynamique pour stocker le widget actif
    frame_valeur.widget = None

    on_champ_change()

    tk.Button(fenetre_recherche, text="Rechercher", command=lancer_recherche).grid(row=2, columnspan=2)

def afficher_image():
    try:
        image = Image.open("graphe.png")
        image = image.resize((500, 400))  # Ajuste la taille si nécessaire
        photo = ImageTk.PhotoImage(image)
        image_label.config(image=photo)
        image_label.image = photo
    except Exception as e:
        messagebox.showerror("Erreur", f"Erreur lors de l'affichage de l'image : {str(e)}")

def quitter_application():
    root.destroy()

# Mapping des options de recherche : "nom affiché" -> (colonne SQL, opérateur, conversion)
options = {
    "Marque": ("marque", "=", str),
    "Modele": ("modele", "=", str),
    "Kilometrage <": ("kilometrage", "<", int),
    "Puissance >": ("puissance", ">", int),
    "Poids <": ("poids", "<", int),
    "Couleur": ("couleur", "=", str),
    "Etat": ("etat", "=", str),
    "Prix <": ("prix", "<", int),
    "Type": ("type", "=", str),
    "Crit'air": ("critair", "=", int),
    "Coffre >": ("coffre", ">", int),
}


# ========================
# = Widgets et Layout UI =
# ========================

frame_boutons = tk.Frame(root)
frame_boutons.pack(pady=10)

tk.Button(frame_boutons, text="Ajouter", command=ajouter_vehicule).pack(side=tk.LEFT, padx=5)
tk.Button(frame_boutons, text="Supprimer", command=supprimer_vehicule).pack(side=tk.LEFT, padx=5)
tk.Button(frame_boutons, text="Rechercher", command=rechercher_vehicule).pack(side=tk.LEFT, padx=5)
tk.Button(frame_boutons, text="Afficher le graphe", command=creer_graphe).pack(side=tk.LEFT, padx=5)
tk.Button(frame_boutons, text="Afficher tous", command=afficher_vehicules).pack(side=tk.LEFT, padx=5)
tk.Button(frame_boutons, text="Quitter", command=quitter_application).pack(side=tk.LEFT, padx=5)

# Tableau
colonnes = ["Marque", "Modele", "Annee", "Kilometrage", "Puissance", "Poids",
            "Couleur", "Etat", "Prix", "Type", "Crit'air", "Coffre", "Hauteur", "Longueur", "Largeur"]
tree = ttk.Treeview(root, columns=colonnes, show="headings")
for col in colonnes:
    tree.heading(col, text=col)
    tree.column(col, width=80)
tree.pack(expand=True, fill="both")

# Label pour l'image du graphe
image_label = tk.Label(root)
image_label.pack(pady=10)

# Lancer avec l'affichage
afficher_vehicules()
root.mainloop()
connexion.close()
