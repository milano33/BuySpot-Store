Sur spyder, ne pas oublier d'ouvrir le fichier et non pas de copier coller le code.

Dans visual studio code, exécuter :
    - pip install tkinter
    - pip install sqlite3
    - pip install networkx
    - pip install matplotlib
    - pip install matplotlib.pylot
    - pip install PIL
